$(document).ready(function(){
    $(document).keyup(function(event){
            if(event.keyCode==27){
                if(confirm_hide==1){
                $(".Background-white").hide();
        $(".Confirm").hide();
        confirm_hide=0;
                }
            }
        });
      $("#Team .See-more-box").click(function(){
        $(this).hide();
        $(this).parent("div").animate({"height":1200},500);
        $(this).siblings(".Profile-view").css({"overflow":"visible"});
        $(this).siblings(".Profile-view ul").stop().slideDown(1236);
    });
});